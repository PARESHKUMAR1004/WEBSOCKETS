import React from 'react'
import NewChatRoom from './components/NewChatRoom'

const App = () => {
  return (
    <NewChatRoom />
  )
}

export default App;

