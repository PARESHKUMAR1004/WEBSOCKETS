package com.server.restmysql.model;



import lombok.*;

import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class Message {
   
    private String receiverName;
    private String message;
    
    
    
	public Message(String receiverName, String message) {
		super();
		this.receiverName = receiverName;
		this.message = message;
		
	}
	public Message() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getReceiverName() {
		return receiverName;
	}
	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
    
    
	
}
