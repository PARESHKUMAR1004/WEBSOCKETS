package com.server.restmysql.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
//import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Trades {

	
	/*@Column(name="Trade_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long Trade_id;*/
	
	@Id
	@GeneratedValue
	private Long Trade_id;
	
	@Column(name = "time", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private java.sql.Timestamp time;

	@Column(name = "buyer_id")
	private Integer buyer_id;

	@Column(name = "seller_id")
	private Integer seller_id;

	@Column(name = "buyer_order_id")
	private Integer buyer_order_id;

	@Column(name = "seller_order_id")
	private Integer seller_order_id;

	@Column(name = "volume")
	private Integer volume;
	@Column(name = "price")
	private double price;
	@Column(name = "symbol")
	private String symbol;

	public Trades() {

	}

	public Long getTrade_id() {
		return Trade_id;
	}

	public void setTrade_id(Long trade_id) {
		Trade_id = trade_id;
	}

	public java.sql.Timestamp getTime() {
		return time;
	}

	public void setTime(java.sql.Timestamp time) {
		this.time = time;
	}

	public Integer getBuyer_id() {
		return buyer_id;
	}

	public void setBuyer_id(Integer buyer_id) {
		this.buyer_id = buyer_id;
	}

	public Integer getSeller_id() {
		return seller_id;
	}

	public void setSeller_id(Integer seller_id) {
		this.seller_id = seller_id;
	}

	public Integer getBuyer_order_id() {
		return buyer_order_id;
	}

	public void setBuyer_order_id(Integer buyer_order_id) {
		this.buyer_order_id = buyer_order_id;
	}

	public Integer getSeller_order_id() {
		return seller_order_id;
	}

	public void setSeller_order_id(Integer seller_order_id) {
		this.seller_order_id = seller_order_id;
	}

	public Integer getVolume() {
		return volume;
	}

	public void setVolume(Integer volume) {
		this.volume = volume;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	

	

	
}
